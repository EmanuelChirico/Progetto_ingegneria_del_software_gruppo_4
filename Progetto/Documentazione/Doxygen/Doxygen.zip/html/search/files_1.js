var searchData=
[
  ['gestionefile_2ejava_0',['GestioneFile.java',['../_gestione_file_8java.html',1,'']]]
];
