var searchData=
[
  ['ricercacontatto_0',['ricercaContatto',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_rubrica.html#a734d16b62e93e67d768f932b68f09fd2',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Rubrica']]],
  ['rimuovicontatto_1',['rimuoviContatto',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_rubrica.html#aee5660a40269247d7890fb3aee87ab35',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Rubrica']]]
];
