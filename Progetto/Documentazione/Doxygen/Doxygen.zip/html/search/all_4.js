var searchData=
[
  ['importacontatti_0',['importaContatti',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_gestione_file.html#a4ba36ec4dfeac76a9b7c926c0dd99316',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::GestioneFile']]],
  ['init_1',['init',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html#a8c5c6facf01f8334237b80cc43fc23bc',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::InterfacciaUtente']]],
  ['interfacciautente_2',['InterfacciaUtente',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica']]],
  ['interfacciautente_2ejava_3',['InterfacciaUtente.java',['../_interfaccia_utente_8java.html',1,'']]]
];
