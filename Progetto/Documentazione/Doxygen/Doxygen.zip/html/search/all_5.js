var searchData=
[
  ['main_0',['main',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html#a1376c4f0f9a16b2573a02ee83cb07692',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::InterfacciaUtente']]],
  ['modificacontatto_1',['modificaContatto',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_rubrica.html#ad0ac0369abb28121b345788a7b571fd4',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Rubrica']]]
];
