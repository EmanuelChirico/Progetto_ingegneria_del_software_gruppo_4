var searchData=
[
  ['visualizzaricerca_0',['visualizzaRicerca',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html#a110298f98ff337880a668fd38a4c360d',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::InterfacciaUtente']]],
  ['visualizzarubrica_1',['visualizzaRubrica',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html#a5024fce116072acc8b42ed56f1957ca7',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::InterfacciaUtente']]]
];
