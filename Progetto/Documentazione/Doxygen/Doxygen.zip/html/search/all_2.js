var searchData=
[
  ['esportacontatti_0',['esportaContatti',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_gestione_file.html#a8597fde76d05f0f3059ff780f7d052e9',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::GestioneFile']]]
];
