var searchData=
[
  ['setcognome_0',['setCognome',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#acdfc26cf067170c0a6aae89c1b7433b8',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['setemail_1',['setEmail',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#a17db27301ca3eda0c5c2548ba37c1121',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['setnome_2',['setNome',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#a91c51f2f88d112e0e2b6ed6d4a98e97f',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['setnumtel_3',['setNumTel',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#a9b603dfda5ca40a4e4a17665c0400a62',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['start_4',['start',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html#a4c1b2e8d970826a4581a256e5d7bf0b1',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::InterfacciaUtente']]],
  ['stop_5',['stop',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_interfaccia_utente.html#a11cf4153b3bb06ed0aa24fbfc67866cf',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::InterfacciaUtente']]]
];
