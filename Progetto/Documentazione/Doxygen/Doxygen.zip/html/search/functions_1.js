var searchData=
[
  ['clona_0',['clona',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_rubrica.html#a6d178d6d2f7f7f3c39a9b459e4231a9f',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Rubrica']]],
  ['confermamodifiche_1',['confermaModifiche',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_rubrica.html#a915e34102ebeb659d5de69607deba672',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Rubrica']]]
];
