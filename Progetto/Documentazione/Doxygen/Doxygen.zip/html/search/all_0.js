var searchData=
[
  ['aggiungicontatto_0',['aggiungiContatto',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_rubrica.html#a90964b62c0f9efe01c300df61a5bb722',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Rubrica']]]
];
