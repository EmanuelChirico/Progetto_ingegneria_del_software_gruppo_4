var searchData=
[
  ['interfacciautente_2ejava_0',['InterfacciaUtente.java',['../_interfaccia_utente_8java.html',1,'']]]
];
