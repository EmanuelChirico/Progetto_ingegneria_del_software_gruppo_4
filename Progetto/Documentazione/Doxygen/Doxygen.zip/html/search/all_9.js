var searchData=
[
  ['tostring_0',['toString',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#a81e47f45bf63611556353099f84fb13e',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]]
];
