var searchData=
[
  ['gestionefile_0',['GestioneFile',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_gestione_file.html',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica']]]
];
