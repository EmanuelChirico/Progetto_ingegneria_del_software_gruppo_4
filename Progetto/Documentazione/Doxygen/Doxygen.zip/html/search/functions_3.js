var searchData=
[
  ['getcognome_0',['getCognome',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#a650a6ba3f05846cf0c740a310e9b2524',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['getemail_1',['getEmail',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#a92bb96bc95b7855e5d5a47bf3c1e6d94',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['getnome_2',['getNome',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#affc2aaaf7f14ea9408df701adcbd9a41',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]],
  ['getnumtel_3',['getNumTel',['../classit_1_1diem_1_1unisa_1_1ingsoft_1_1gruppoiv_1_1rubrica_1_1_contatto.html#adf31ed420f6d2f7bb459c9762ca41f5d',1,'it::diem::unisa::ingsoft::gruppoiv::rubrica::Contatto']]]
];
