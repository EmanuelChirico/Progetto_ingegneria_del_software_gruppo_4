var searchData=
[
  ['nomeproperty_0',['nomeProperty',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a393d2c6059d5335a75bfb7e6b71dec84',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['numeroduplicato_1',['numeroDuplicato',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#a4a9051c9e9e265d3f28120e67bc29602',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::GestoreRubrica']]],
  ['numtelproperty_2',['numTelProperty',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a3f46f15ccac0de27dcff147f061b3020',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]]
];
