var searchData=
[
  ['secondarycontroller_0',['SecondaryController',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html',1,'it::unisa::diem::ingsoft::gruppo4::view']]],
  ['secondarycontroller_2ejava_1',['SecondaryController.java',['../_secondary_controller_8java.html',1,'']]],
  ['setcognome_2',['setCognome',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a370a9033071798b258e67c90bb7e2b16',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['setcontattodamodificare_3',['setContattoDaModificare',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a49c3fe90f1ff5fbdbe6741cdf32698fe',1,'it::unisa::diem::ingsoft::gruppo4::view::SecondaryController']]],
  ['setemail_4',['setEmail',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#ae36dbcd3168f1b966f381d3c6220a7e1',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['setmodalitamodifica_5',['setModalitaModifica',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a840c1de73b3aa003a0a9731e5224bf9e',1,'it::unisa::diem::ingsoft::gruppo4::view::SecondaryController']]],
  ['setnome_6',['setNome',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#abb643500c4798fdbe97e366ec2e479c4',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['setnumtel_7',['setNumTel',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a183000486fb5657baceaa6f18623cb02',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['setprimarycontroller_8',['setPrimaryController',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a7586dd7157e57ea6d0d8e7654a2ede56',1,'it::unisa::diem::ingsoft::gruppo4::view::SecondaryController']]],
  ['setrubrica_9',['setRubrica',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_primary_controller.html#ae679bb867c1e541b346d95ce419f4bae',1,'it.unisa.diem.ingsoft.gruppo4.view.PrimaryController.setRubrica()'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a83ddbee5b1fc71c9599e62456b0fe33c',1,'it.unisa.diem.ingsoft.gruppo4.view.SecondaryController.setRubrica()']]],
  ['start_10',['start',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_interfaccia_utente.html#a6592a5fd3f459ae7c50e747b6be481f5',1,'it::unisa::diem::ingsoft::gruppo4::view::InterfacciaUtente']]],
  ['stop_11',['stop',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_interfaccia_utente.html#a616bde80f7177ab2542dd2f00572f69f',1,'it::unisa::diem::ingsoft::gruppo4::view::InterfacciaUtente']]],
  ['svuotarubrica_12',['svuotaRubrica',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#ae96b8ae19638a627c11340afbc8735de',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::GestoreRubrica']]]
];
