var searchData=
[
  ['emailproperty_0',['emailProperty',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a93595761301d821ac9689e7963a43986',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['esportacontatti_1',['esportaContatti',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_file.html#a5554f8d1505ef55ba7b5b5d0e2559cba',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::GestoreFile']]]
];
