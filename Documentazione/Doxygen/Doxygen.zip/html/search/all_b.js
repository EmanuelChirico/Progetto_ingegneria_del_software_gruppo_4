var searchData=
[
  ['tostring_0',['toString',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#afd35745d114f8acfeafb457443fa68d1',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]]
];
