var searchData=
[
  ['gestorerubrica_2ejava_0',['GestoreRubrica.java',['../_gestore_rubrica_8java.html',1,'']]]
];
