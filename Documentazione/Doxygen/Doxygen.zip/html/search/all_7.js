var searchData=
[
  ['operazionirubrica_0',['OperazioniRubrica',['../interfaceit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_operazioni_rubrica.html',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica']]],
  ['operazionirubrica_2ejava_1',['OperazioniRubrica.java',['../_operazioni_rubrica_8java.html',1,'']]]
];
