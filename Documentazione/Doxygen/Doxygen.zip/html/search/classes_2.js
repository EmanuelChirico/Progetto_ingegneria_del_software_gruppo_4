var searchData=
[
  ['interfacciautente_0',['InterfacciaUtente',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_interfaccia_utente.html',1,'it::unisa::diem::ingsoft::gruppo4::view']]]
];
