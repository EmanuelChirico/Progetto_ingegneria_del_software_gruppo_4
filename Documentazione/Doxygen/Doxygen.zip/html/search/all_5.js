var searchData=
[
  ['main_0',['main',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_interfaccia_utente.html#ac0bd92d9392096f3033eaf2e6992f406',1,'it::unisa::diem::ingsoft::gruppo4::view::InterfacciaUtente']]],
  ['modificacontatto_1',['modificaContatto',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#a7b209972a0a0f288f8b567c18d8e77d6',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.GestoreRubrica.modificaContatto()'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_rubrica.html#a128a63b1d0bb247ec22a7ef8778d1533',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.Rubrica.modificaContatto()']]]
];
