var searchData=
[
  ['gestorefile_0',['GestoreFile',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_file.html',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica']]],
  ['gestorerubrica_1',['GestoreRubrica',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.GestoreRubrica'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#ae6f2c5affebd9cd03b1dfe3dc316ab40',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.GestoreRubrica.GestoreRubrica()']]],
  ['gestorerubrica_2ejava_2',['GestoreRubrica.java',['../_gestore_rubrica_8java.html',1,'']]],
  ['getcognome_3',['getCognome',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a26eed74947ba934b34a46c4686c5fd69',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['getcontatti_4',['getContatti',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#a262d7c00b118455f1fbf1571a95ab350',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::GestoreRubrica']]],
  ['getemail_5',['getEmail',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a538fe3f115dc948f45e06dcda45f2929',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['getnome_6',['getNome',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#aaa53800ef80a7c65936649c410de53d7',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['getnumtel_7',['getNumTel',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a3a76bda78a62b12d60c453c20a8e30d7',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['gettableview_8',['getTableView',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_primary_controller.html#a30672b464af93bb0025161e85b64ed06',1,'it::unisa::diem::ingsoft::gruppo4::view::PrimaryController']]]
];
