var searchData=
[
  ['addcontacttotable_0',['addContactToTable',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_primary_controller.html#a84704fcc34323f33aaf2658ae37fed34',1,'it::unisa::diem::ingsoft::gruppo4::view::PrimaryController']]],
  ['aggiornatabella_1',['aggiornaTabella',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_primary_controller.html#ad9312bef9c37665f89faa52f56724ccd',1,'it::unisa::diem::ingsoft::gruppo4::view::PrimaryController']]],
  ['aggiungicontatto_2',['aggiungiContatto',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#a0d544926079098f6036947e52a20d11a',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.GestoreRubrica.aggiungiContatto()'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_rubrica.html#a8415e8f4363f447ab53b93137debb592',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.Rubrica.aggiungiContatto()']]]
];
