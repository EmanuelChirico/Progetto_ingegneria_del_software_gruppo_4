var searchData=
[
  ['operazionirubrica_2ejava_0',['OperazioniRubrica.java',['../_operazioni_rubrica_8java.html',1,'']]]
];
