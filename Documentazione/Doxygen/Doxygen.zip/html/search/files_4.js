var searchData=
[
  ['primarycontroller_2ejava_0',['PrimaryController.java',['../_primary_controller_8java.html',1,'']]]
];
