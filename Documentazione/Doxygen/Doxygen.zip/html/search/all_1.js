var searchData=
[
  ['cognomeproperty_0',['cognomeProperty',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#a52bef58efe903c7c9732ae48b051063a',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::Contatto']]],
  ['contatto_1',['Contatto',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.Contatto'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_contatto.html#afbefbc9ca0616f54cb23c462fffa7c19',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.Contatto.Contatto()']]],
  ['contatto_2ejava_2',['Contatto.java',['../_contatto_8java.html',1,'']]]
];
