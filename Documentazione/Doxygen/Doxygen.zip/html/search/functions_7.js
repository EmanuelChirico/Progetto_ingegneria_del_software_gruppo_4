var searchData=
[
  ['ricercacontatto_0',['ricercaContatto',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#aab1a92825ec8147b328c38b5f2be61cc',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.GestoreRubrica.ricercaContatto()'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_rubrica.html#a1b4769f1cc54b5b3c64e682bc9d44702',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.Rubrica.ricercaContatto()']]],
  ['rimuovicontatto_1',['rimuoviContatto',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_rubrica.html#aa06d704649b3de889a3e41e2ef0edfea',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.GestoreRubrica.rimuoviContatto()'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_rubrica.html#a47bb0f56fee7ecca41f5ce44ec650d90',1,'it.unisa.diem.ingsoft.gruppo4.Rubrica.Rubrica.rimuoviContatto()']]]
];
