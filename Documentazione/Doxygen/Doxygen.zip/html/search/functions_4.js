var searchData=
[
  ['importacontatti_0',['importaContatti',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1_rubrica_1_1_gestore_file.html#ae3d2e2e3ed514c9a2a9acd2fe890ca9e',1,'it::unisa::diem::ingsoft::gruppo4::Rubrica::GestoreFile']]],
  ['init_1',['init',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_interfaccia_utente.html#ab004fb737ddefe5c2f28c5cacf1324bb',1,'it::unisa::diem::ingsoft::gruppo4::view::InterfacciaUtente']]],
  ['initialize_2',['initialize',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_primary_controller.html#a1c75faeea4ccc8aeff4a3b1730088858',1,'it.unisa.diem.ingsoft.gruppo4.view.PrimaryController.initialize()'],['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a89e02683627de9a62781f5bb3b80de78',1,'it.unisa.diem.ingsoft.gruppo4.view.SecondaryController.initialize()']]],
  ['isvalidemail_3',['isValidEmail',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a5ddb6ba4e3bc9caca28a596717fb6c6f',1,'it::unisa::diem::ingsoft::gruppo4::view::SecondaryController']]],
  ['isvalidnumtel_4',['isValidNumTel',['../classit_1_1unisa_1_1diem_1_1ingsoft_1_1gruppo4_1_1view_1_1_secondary_controller.html#a9e9e8a3c4841c3d4723d1166615183ac',1,'it::unisa::diem::ingsoft::gruppo4::view::SecondaryController']]]
];
